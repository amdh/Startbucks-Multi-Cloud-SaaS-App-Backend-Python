
create requirements.txt having needed python packages

Elastic beanstalk user for python application

AKIAIAFVYDDXOU5DGV2Q : Access key 
secret Access key : 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

using aws eb cli:

eb init : to create application - set basic info

eb create : to create environment to deploy

eb deploy :  to deploythe app on server

eb open : open the url on browser